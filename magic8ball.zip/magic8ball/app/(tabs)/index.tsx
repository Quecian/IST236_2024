import React, { useState } from 'react';
import { View, TextInput, Button, Image, StyleSheet, Text } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';

export default function Magic8Ball() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [displayQuestion, setDisplayQuestion] = useState("");

  const shakeBall = () => {
    const randomNumber = Math.floor(Math.random() * 8) + 1;
    let response = "";

    switch (randomNumber) {
      case 1:
        response = "Yes";
        break;
      case 2:
        response = "No";
        break;
      case 3:
        response = "Ask again later";
        break;
      case 4:
        response = "Definitely";
        break;
      case 5:
        response = "Very doubtful";
        break;
      case 6:
        response = "Without a doubt";
        break;
      case 7:
        response = "Better not tell you now";
        break;
      case 8:
        response = "Signs point to yes";
        break;
    }

    setAnswer(response);
    setDisplayQuestion(question);
  };

  return (
    <ThemedView style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Ask your question"
        value={question}
        onChangeText={setQuestion}
      />
      <Button title="Submit" onPress={shakeBall} />
      {displayQuestion !== "" && (
        <View style={styles.answerContainer}>
          <Text style={styles.question}>Question: {displayQuestion}</Text>
          <View style={styles.ballWrapper}>
            <Image
              source={require('@/assets/images/magic8ball.jpg')}
              style={styles.ballImage}
            />
            <Text style={styles.answer}>{answer}</Text>
          </View>
        </View>
      )}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  input: {
    width: '80%',
    padding: 10,
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 20,
    borderRadius: 5,
  },
  answerContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  question: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  ballWrapper: {
    position: 'relative',
    width: 200,
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ballImage: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  answer: {
    position: 'absolute',
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
});
