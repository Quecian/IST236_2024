import { Image, StyleSheet, FlatList, View, ImageSourcePropType } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';

interface Movie {
  title: string;
  poster: ImageSourcePropType;
  rating: number;
}

const movies: Movie[] = [
  {
    title: 'Unleashed (2005)',
    poster: require('@/assets/images/campbell04images/unleashed.jpg'),
    rating: 7.0,
  },
  {
    title: 'Little Nicky',
    poster: require('@/assets/images/campbell04images/littlenicky.jpg'),
    rating: 5.3,
  },
  {
    title: '2 Fast 2 Furious',
    poster: require('@/assets/images/campbell04images/2fast2furious.jpg'),
    rating: 5.9,
  },
  {
    title: 'The Day After Tomorrow',
    poster: require('@/assets/images/campbell04images/dayaftertomorrow.jpg'),
    rating: 6.4,
  },
  {
    title: 'Final Destination 3',
    poster: require('@/assets/images/campbell04images/finaldestination3.jpg'),
    rating: 5.8,
  },
  {
    title: 'Superhero Movie',
    poster: require('@/assets/images/campbell04images/superheromovie.jpg'),
    rating: 4.5,
  },
  {
    title: 'Pokemon: The First Movie',
    poster: require('@/assets/images/campbell04images/pokemonthefirstmovie.jpg'),
    rating: 6.1,
  },
  {
    title: 'The Devils Advocate',
    poster: require('@/assets/images/campbell04images/thedevilsadvocate.jpg'),
    rating: 7.5,
  },
  {
    title: '8 Mile',
    poster: require('@/assets/images/campbell04images/8mile.jpg'),
    rating: 7.1,
  },
  {
    title: 'Scary Stories to Tell in the Dark',
    poster: require('@/assets/images/campbell04images/scarystoriestotellinthedark.jpg'),
    rating: 6.2,
  },
];

const MovieItem = ({ title, poster, rating }: Movie) => {
  return (
    <View style={styles.movieItemContainer}>
      <Image source={poster} style={styles.moviePoster} />
      <ThemedView style={styles.movieDetails}>
        <ThemedText type="title">{title}</ThemedText>
        <ThemedText type="subtitle">Rating: {rating}</ThemedText>
      </ThemedView>
    </View>
  );
};

export default function HomeScreen() {
  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title" style={styles.mainTitle}>
        Top 10 Movies
      </ThemedText>
      <FlatList
        data={movies}
        renderItem={({ item }) => (
          <MovieItem title={item.title} poster={item.poster} rating={item.rating} />
        )}
        keyExtractor={(item) => item.title}
        style={styles.list}
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "aliceblue",
  },
  mainTitle: {
    marginTop: 50,
    textAlign: 'center',
    marginBottom: 16,
  },
  list: {
    marginTop: 16,
    backgroundColor:"aliceblue"
  },
  movieItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    backgroundColor: "aliceblue"
    
  },
  moviePoster: {
    width: 100,
    height: 150,
    marginRight: 16,
    backgroundColor: "aliceblue"

  },
  movieDetails: {
    flex: 1,
    backgroundColor: "aliceblue"

  },
});
