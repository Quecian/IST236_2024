import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

type RootStackParamList = {
  AddRecipe: { setRecipes: React.Dispatch<React.SetStateAction<{ id: string; title: string; text: string }[]>> };
};

type Props = NativeStackScreenProps<RootStackParamList, 'AddRecipe'>;

const AddRecipeScreen = ({ route, navigation }: Props) => {
  const { setRecipes } = route.params;
  const [newRecipe, setNewRecipe] = useState({ title: '', text: '' });

  const handleSave = () => {
    if (newRecipe.title && newRecipe.text) {
      setRecipes((prevRecipes) => [
        ...prevRecipes,
        { id: Math.random().toString(), ...newRecipe },
      ]);
      navigation.goBack();
    } else {
      alert('Please fill out all fields!');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Recipe Title"
        value={newRecipe.title}
        onChangeText={(text) => setNewRecipe({ ...newRecipe, title: text })}
      />
      <TextInput
        style={styles.input}
        placeholder="Recipe Instructions"
        value={newRecipe.text}
        onChangeText={(text) => setNewRecipe({ ...newRecipe, text })}
        multiline
      />
      <Button title="Save" onPress={handleSave} />
      <Button title="Cancel" onPress={() => navigation.goBack()} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 8,
    borderRadius: 4,
  },
});

export default AddRecipeScreen;
