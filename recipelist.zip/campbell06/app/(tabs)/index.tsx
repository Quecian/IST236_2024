import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { Button, View, Text, StyleSheet, FlatList, Modal } from "react-native";
import AddRecipeScreen from "./AddRecipeScreen"; // Ensure the correct path

const Stack = createStackNavigator();

const App = () => {
  const [recipes, setRecipes] = useState<
    { id: string; title: string; text: string }[]
  >([
    { id: "1", title: "Pasta", text: "Boil pasta, add sauce." },
    { id: "2", title: "Salad", text: "Chop veggies, add dressing." },
  ]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<{
    id: string;
    title: string;
    text: string;
  } | null>(null);

  const handleDelete = (id: string) => {
    setRecipes((prevRecipes) =>
      prevRecipes.filter((recipe) => recipe.id !== id)
    );
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" options={{ title: "Recipes App" }}>
          {(props) => (
            <View style={styles.container}>
              <Text style={styles.header}>Recipes List</Text>
              <FlatList
                data={recipes}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.recipeContainer}>
                    <Text style={styles.title}>{item.title}</Text>
                    <View style={styles.buttonRow}>
                      <Button
                        title="View"
                        onPress={() => {
                          setSelectedRecipe(item);
                          setModalVisible(true);
                        }}
                      />
                      <Button
                        title="Delete"
                        onPress={() => handleDelete(item.id)}
                      />
                    </View>
                  </View>
                )}
              />
              <Button
                title="Add Recipe"
                onPress={() =>
                  props.navigation.navigate("AddRecipe", { setRecipes })
                }
              />
            </View>
          )}
        </Stack.Screen>

        <Stack.Screen name="AddRecipe" component={AddRecipeScreen} />
      </Stack.Navigator>

      {/* Modal for viewing recipe details */}
      {selectedRecipe && (
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>{selectedRecipe.title}</Text>
              <Text>{selectedRecipe.text}</Text>
              <Button title="Close" onPress={() => setModalVisible(false)} />
            </View>
          </View>
        </Modal>
      )}
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  recipeContainer: {
    backgroundColor: "#fff",
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    borderColor: "#ddd",
    borderWidth: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 8,
    width: 300,
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
  },
});

export default App;
